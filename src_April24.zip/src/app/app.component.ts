import { Component } from '@angular/core';

@Component({
  selector: 'app-root1',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  newServerName = '';
  newServerContnet = '';

  servers = [];

  onAddServer() {
    this.servers.push({
      name : this.newServerName,
      content : this.newServerContnet,
      type : 'server'
    })
  }
  onAddBluePrint(){
    this.servers.push({
      name : this.newServerName,
      content : this.newServerContnet,
      type : 'blueprint'
    })
  }

}
