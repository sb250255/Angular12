import {Component} from '@angular/core'

@Component({
    selector : 'app-server',
    templateUrl: './server.component.html'
})

export class ServerComponent{
    serverStatus = "Not Up & Not Running"
    SetStatus = false;
    data = "This text is from server"
    uname;
    constructor() {
        setTimeout(() => {
          this.SetStatus = true;
        }, 20000);
      }
      onClick (){
          this.SetStatus = true;
      }

      OnReset(){
            this.uname = '';
      }
}
