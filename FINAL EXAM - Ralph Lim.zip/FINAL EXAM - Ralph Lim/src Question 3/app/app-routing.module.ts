import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import{Routes,RouterModule} from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { ContactComponent } from './contact/contact.component'; 
import { ResumeComponent } from './resume/resume.component';
import { SkillsComponent } from './skills/skills.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';

const appRoutes:Routes=[
  {  path:'home',component:HomeComponent},
  {  path:'about',component:AboutComponent},
   {  path:'portfolio',component:PortfolioComponent},
   {  path:'resume',component:ResumeComponent} ,
    {  path:'skills',component:SkillsComponent} , 
    {  path:'deals',component:ContactComponent},
    {  path:'testimonials',component:TestimonialsComponent},
]

@NgModule({
  imports:[
    RouterModule.forRoot(appRoutes)
    ],
    exports:[
    RouterModule
    ]
    })
export class AppRoutingModule { }
